/**
 * 
 */
package FPGA;

import java.util.Scanner;

/**
 * @author Rafal Weronika
 * ProjektowanieSystemow.java
 */
public class ArrayLista {


	public static void rozklad() {
		System.out.println("Podaj rozmiar macierzy");
		Scanner sc = new Scanner(System.in);
		int rozmiar = sc.nextInt();
	//	double[][]tab = new double[rozmiar][rozmiar];
		double[][]L = new double[rozmiar][rozmiar];
		double[][]U = new double[rozmiar][rozmiar];
		
		
		
		int tab[][] = { { 2, -1, -2 }, 
						{ -4, 6, 3 }, 
						{ -4, -2, 8 } }; 
		int iloscWierszy;

		 //gniazdo pierwsze
		System.out.println("Pierwsze gniazdo");
		 System.out.println("Nr"+ "|" + " " + "W1"+ " " + "W2"+ " " + "W3" + " " + "Lij" +" " + "Ujk" + " " + "Uik" + " " + "tabik");
		 int nr = 0;
		 int W1,W2,W3;
		 W3 = -1;
		 int Uik [] = new int[2];
		 int tabik [] = new int[2];
		 int Ujk [] = new int[2];
		 int Lij [] = new int[2];
		 for (int i = 0; i < rozmiar; i++) { 
			 
			 
		        zad : for (int k = i; k < rozmiar; k++) { 
		        	
		            int sum = 0; 
		            
		            
		            
		            
		            for (int j = 0; j < i; j++) 
		            {
		            	 sum += (L[i][j] * U[j][k]); 
		            	 if (j >= 0)
		            	 {
		            		nr++;
		 		            W1 = i;
		 		            W2 = k;
		 		            W3 = j;
		 		            
		 		            Lij[0] = i;
		 		            Lij[1] = j;
		 		             
		 		           
		 		            Ujk[0] = j;
		 		            Ujk[1] = k;
		 		            
		 		           Uik[0] = i;
		 		           Uik[1] = k;
		 		           
		 		           tabik[0] = i;
		 		           tabik[1] = k;
		 		            
		            		System.out.println(nr + "|" + " " + " "+  W1 + " " +  W2 +  " " + W3 +"  " + Lij[0] + Lij[1]+ "  " + Ujk[0] + Ujk[1] + " " + Uik[0] + Uik[1] + " " + tabik[0] + tabik[1]);
		            		
		            	 }
		             
		                
		              
		            }
		            U[i][k] = tab[i][k] - sum;
		            
		            
		            
		            if (W3 > -1)
		            {
		            	continue zad;
		            }
		            Lij[0] = i;
 		            Lij[1] = W3;
 		            Ujk[0] = W3;
 		            Ujk[1] = k;
 		           Uik[0] = i;
 		           Uik[1] = k;
 		           
 		           tabik[0] = i;
 		           tabik[1] = k;
		            nr++;
		            W1 = i;
		            W2 = k;
		            System.out.println(nr + "|" + " " + " "+  W1 + " " +  W2 +  " " + W3 +"  " + Lij[0] + Lij[1]+ "  " + Ujk[0] + Ujk[1] + " " + Uik[0] + Uik[1] + " " + tabik[0] + tabik[1]);
		            
		           
		          
		            
		          
		        } 
		 }
		// koniec pierwszego gniazda petli
	    //lacznie z pierwszym for
		        
		 
		 // drugie gniazdo
		 		System.out.println();
		        System.out.println("Drugie gniazdo");
		        System.out.println("Nr"+ "|" + " " + "W1"+ " " + "W2"+ " " + "W3" + " " + "Lkj" + " " + "Uji" + " " + "tabki" + " " + "Uii"+" "+"Lki");
		        int nr2 = 0;
				int W11,W22,W33;
				W33 = -1;
				int Lkj [] = new int[2];
				int Uji [] = new int[2];
				int tabki [] = new int[2];
				int Uii [] = new int[2];
				int Lki [] = new int[2];
		  
		    for (int i = 0; i < rozmiar; i++) { 
		    	
		      zad2:  for (int k = i; k < rozmiar; k++) { 
		            if (i == k) 
		            {
		                L[i][i] = 1; // Ustawianie 1 po diagonali
		                nr2++;
	 		            W11 = i;
	 		            W22 = k;
	 		            
	 		           Lkj[0] = k;
	 		           Lkj[1] = W33;
	 		             
	 		           
	 		          Uji[0] = k;
	 		          Uji[1] = i;
	 		            
	 		           Uii[0] = i;
	 		           Uii[1] = i;
	 		           
	 		           tabki[0] = k;
	 		           tabki[1] = i;
	 		           
	 		          Lki[0] = k;
	 		           Lki[1] = i;
	 		            
	            		System.out.println(nr2 + "|" + " " + " "+  W11 + " " +  W22 +  " " + W33 + " " + Lkj[0] + Lkj[1] + " " + Uji[0] + Uji[1] + " " + Uii[0] + Uii[1] + " " + tabki[0] + tabki[1] + " " + Lki[0] + Lki[1]);
		            }
		            else { 
		  
		               
		                int sum = 0; 
		                for (int j = 0; j < i; j++)
		                {
		                    sum += (L[k][j] * U[j][i]); 
		                    nr2++;
		 		            W11 = i;
		 		            W22 = k;
		 		            W33 = j;
		 		            
		 		           Lkj[0] = k;
		 		           Lkj[1] = j;
		 		             
		 		           
		 		          Uji[0] = k;
		 		          Uji[1] = i;
		 		            
		 		           Uii[0] = i;
		 		           Uii[1] = i;
		 		           
		 		           tabki[0] = k;
		 		           tabki[1] = i;
		 		           
		 		          Lki[0] = k;
		 		           Lki[1] = i;
		            		System.out.println(nr2 + "|" + " " + " "+  W11 + " " +  W22 +  " " + W33 + " " + Lkj[0] + Lkj[1] + " " + Uji[0] + Uji[1] + " " + Uii[0] + Uii[1] + " " + tabki[0] + tabki[1] + " " + Lki[0] + Lki[1] );
		  
		                }
		                L[k][i] = (tab[k][i] - sum) / U[i][i]; 
		               
		            } 
		            //koniec drugiego gniazda petli
		            // lacznie z pierwszym for
		            
		            
		            if (W33 > -1 ||i == k )
		            {
		            	continue zad2;
		            }
		            nr2++;
		            W11 = i;
		            W22 = k;
		            Lkj[0] = k;
	 		           Lkj[1] = W33;
	 		             
	 		           
	 		          Uji[0] = k;
	 		          Uji[1] = i;
	 		            
	 		           Uii[0] = i;
	 		           Uii[1] = i;
	 		           
	 		           tabki[0] = k;
	 		           tabki[1] = i;
	 		           
	 		          Lki[0] = k;
	 		           Lki[1] = i;
		            System.out.println(nr2 + "|" + " " + " "+  W11 + " " +  W22 +  " " + W33 + " " + Lkj[0] + Lkj[1] + " " + Uji[0] + Uji[1] + " " + Uii[0] + Uii[1] + " " + tabki[0] + tabki[1] + " " + Lki[0] + Lki[1]);
		        } 
		    } 
		    
		  //koniec drugiego gniazda petli
          // lacznie z drugim zewnetrznym for
		    System.out.println();
		    
		 for (int i = 0; i < rozmiar; i++) { 
		        // Wyświetlanie macierzy L
			 
		        for (int j = 0; j < rozmiar; j++) 
		            System.out.print(L[i][j] + "\t");  
		        System.out.println();
		    } 
		 
		 System.out.println();
		 
		 
		 for (int i = 0; i < rozmiar; i++) { 
		        // Wyświetlanie macierzy U 
		        for (int j = 0; j < rozmiar; j++) 
		            System.out.print(U[i][j] + "\t");  
		  		        System.out.println(); 
		    } 
		 
		 System.out.println(); 
		
		 // tworzenie macierzy ktora nie bedzie wypisywana
		 // sluzaca jedynie do zliczenia wezlow oraz polaczen
		 // z gniazda pierwszego
		 
		 iloscWierszy = nr + nr2;
		 int tabCala[][] = new int [iloscWierszy][13];
		 iloscWierszy = 0;
		 int jj = -1;
		 for (int i = 0; i < rozmiar; i++) { 
		      zadpetla:  for (int k = i; k < rozmiar; k++) { 
		  
		            int sum = 0; 
		            
		            for (int j = 0; j < i; j++) 
		            {
		                sum += (L[i][j] * U[j][k]);
		                
		                jj = j;
		                tabCala[iloscWierszy][0] = i;
		                tabCala[iloscWierszy][1] = k;
		                tabCala[iloscWierszy][2] = jj;
		                tabCala[iloscWierszy][3] = i;
		                tabCala[iloscWierszy][4] = jj;
		                tabCala[iloscWierszy][5] = jj;
		                tabCala[iloscWierszy][6] = k;
		                tabCala[iloscWierszy][7] = i;
		                tabCala[iloscWierszy][8] = k;
		                tabCala[iloscWierszy][9] = i;
		                tabCala[iloscWierszy][10] = k;
		                tabCala[iloscWierszy][11] = -1;
		                tabCala[iloscWierszy][12] = -1;
		                iloscWierszy ++;
		                
		            }
		            U[i][k] = tab[i][k] - sum; 
		            if (jj > -1)
		            {
		            	continue zadpetla;
		            }
		            
	                tabCala[iloscWierszy][0] = i;
	                tabCala[iloscWierszy][1] = k;
	                tabCala[iloscWierszy][2] = jj;
	                tabCala[iloscWierszy][3] = i;
	                tabCala[iloscWierszy][4] = jj;
	                tabCala[iloscWierszy][5] = jj;
	                tabCala[iloscWierszy][6] = k;
	                tabCala[iloscWierszy][7] = i;
	                tabCala[iloscWierszy][8] = k;
	                tabCala[iloscWierszy][9] = i;
	                tabCala[iloscWierszy][10] = k;
	                tabCala[iloscWierszy][11] = -1;
	                tabCala[iloscWierszy][12] = -1;
	                iloscWierszy ++;
		        } 
		 }	  
		        //drugie gniazdo
		        int jjj = -1;
		   for(int i = 0; i < rozmiar; i ++ )
		   {
		       zad22: for (int k = i; k < rozmiar; k++) { 
		            if (i == k) 
		            {
		                L[i][i] = 1; // Ustawianie 1 po diagonali
		                tabCala[iloscWierszy][0] = i;
		                tabCala[iloscWierszy][1] = k;
		                tabCala[iloscWierszy][2] = jjj;
		                tabCala[iloscWierszy][3] = k;
		                tabCala[iloscWierszy][4] = jjj;
		                tabCala[iloscWierszy][5] = jjj;
		                tabCala[iloscWierszy][6] = i;
		                tabCala[iloscWierszy][7] = k;
		                tabCala[iloscWierszy][8] = i;
		                tabCala[iloscWierszy][9] = i;
		                tabCala[iloscWierszy][10] = i;
		                tabCala[iloscWierszy][11] = k;
		                tabCala[iloscWierszy][12] = i;
		                iloscWierszy ++;
		            }
		            else { 
		  
		               
		                int sum = 0; 
		                for (int j = 0; j < i; j++) 
		                {
		                    sum += (L[k][j] * U[j][i]); 
		  
		                
		                L[k][i] = (tab[k][i] - sum) / U[i][i]; 
		                
		                jjj = j;
		                tabCala[iloscWierszy][0] = i;
		                tabCala[iloscWierszy][1] = k;
		                tabCala[iloscWierszy][2] = jjj;
		                tabCala[iloscWierszy][3] = k;
		                tabCala[iloscWierszy][4] = jjj;
		                tabCala[iloscWierszy][5] = jjj;
		                tabCala[iloscWierszy][6] = i;
		                tabCala[iloscWierszy][7] = k;
		                tabCala[iloscWierszy][8] = i;
		                tabCala[iloscWierszy][9] = i;
		                tabCala[iloscWierszy][10] = i;
		                tabCala[iloscWierszy][11] = k;
		                tabCala[iloscWierszy][12] = i;
		                iloscWierszy ++;
		                }
		                
		            } 
		            if (jjj > -1 ||i == k )
		            {
		            	continue zad22;
		            }
		            tabCala[iloscWierszy][0] = i;
	                tabCala[iloscWierszy][1] = k;
	                tabCala[iloscWierszy][2] = jjj;
	                tabCala[iloscWierszy][3] = k;
	                tabCala[iloscWierszy][4] = jjj;
	                tabCala[iloscWierszy][5] = jjj;
	                tabCala[iloscWierszy][6] = i;
	                tabCala[iloscWierszy][7] = k;
	                tabCala[iloscWierszy][8] = i;
	                tabCala[iloscWierszy][9] = i;
	                tabCala[iloscWierszy][10] = i;
	                tabCala[iloscWierszy][11] = k;
	                tabCala[iloscWierszy][12] = i;
	                iloscWierszy ++;
		        } 
		    } 
		   
		 for (int i = 0; i < iloscWierszy; i ++)
		 {
			 for (int j = 0; j < 13; j++)
			 {
				 System.out.print(tabCala[i][j] + " ");
			 }
			 System.out.println();
		 }
		 
		 
		} 
			 
	
	public static void main(String[] args) {
		rozklad();

	}

}
